 
    library app_icons;
    class AppIcons {

        static const String opps = "assets/svg/opps.svg";
        static const String wifi = "assets/svg/wifi.svg";

    }