// ============================================
// 2. PROFILE SETUP PAGE (Edit Profile)
// lib/features/user/presentation/pages/profile_setup_page.dart
// ============================================

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:warshasy/core/config/config.dart';
import 'package:warshasy/core/storage/repository/local_storage_reposotory.dart';
import 'package:warshasy/features/auth/domain/entities/auth_session.dart';
import 'package:warshasy/features/user/domain/entities/city.dart';
import 'package:warshasy/features/user/presentation/blocs/user_bloc.dart';

class ProfileSetupPage extends StatefulWidget {
  const ProfileSetupPage({super.key});

  @override
  State<ProfileSetupPage> createState() => _ProfileSetupPageState();
}

class _ProfileSetupPageState extends State<ProfileSetupPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _bioController = TextEditingController();
  City? _selectedCity;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _bioController.dispose();
    super.dispose();
  }

  Future<void> _loadUserData() async {
    final storage = sl<LocalStorageRepository>();
    final user = storage.getUser();

    if (user != null) {
      setState(() {
        _nameController.text = user.fullName;
        _bioController.text = user.bio ?? '';
        _selectedCity = user.city;
        _isLoading = false;
      });
    } else {
      setState(() => _isLoading = false);
    }
  }

  void _saveProfile(BuildContext ctx) {
    if (_formKey.currentState!.validate()) {
      //final storage = sl<LocalStorageRepository>();
      //final userId = storage.getUserId();

      String userId = sl<AuthSession>().phone!;

      if (userId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('خطأ: لم يتم العثور على معرف المستخدم')),
        );
        return;
      }

      ctx.read<UserBloc>().add(
        UpdateUserRequested(
          userId: userId,
          fullName: _nameController.text.trim(),
          city: _selectedCity,
          bio:
              _bioController.text.trim().isEmpty
                  ? null
                  : _bioController.text.trim(),
          context: context,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => sl<UserBloc>(),
      child: Builder(
        builder:
            (innerContext) => Scaffold(
              appBar: AppBar(
                title: const Text('تعديل الملف الشخصي'),
                actions: [
                  TextButton(
                    onPressed: () => _saveProfile(innerContext),
                    child: const Text('حفظ', style: TextStyle(fontSize: 16)),
                  ),
                ],
              ),
              body: BlocListener<UserBloc, UserState>(
                listener: (context, state) {
                  if (state is UserUpdated) {
                    // Update local storage
                    final storage = sl<LocalStorageRepository>();
                    storage.saveUser(state.user);

                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('تم تحديث الملف الشخصي بنجاح'),
                      ),
                    );
                    context.pop();
                  }
                },
                child: BlocBuilder<UserBloc, UserState>(
                  builder: (context, state) {
                    if (_isLoading) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    final isSaving = state is UserLoading;

                    return Form(
                      key: _formKey,
                      child: ListView(
                        padding: const EdgeInsets.all(16),
                        children: [
                          // Avatar Section
                          _buildAvatarSection(isSaving),

                          const SizedBox(height: 32),

                          // Name Field
                          TextFormField(
                            controller: _nameController,
                            decoration: const InputDecoration(
                              labelText: 'الاسم الكامل *',
                              hintText: 'أدخل اسمك الكامل',
                              prefixIcon: Icon(Icons.person),
                              border: OutlineInputBorder(),
                            ),
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'الرجاء إدخال الاسم';
                              }
                              if (value.trim().length < 3) {
                                return 'الاسم يجب أن يكون 3 أحرف على الأقل';
                              }
                              return null;
                            },
                            enabled: !isSaving,
                            textInputAction: TextInputAction.next,
                          ),

                          const SizedBox(height: 16),

                          // City Dropdown
                          DropdownButtonFormField<City>(
                            value: _selectedCity,
                            decoration: const InputDecoration(
                              labelText: 'المدينة',
                              hintText: 'اختر مدينتك',
                              prefixIcon: Icon(Icons.location_city),
                              border: OutlineInputBorder(),
                            ),
                            items:
                                City.values.map((city) {
                                  return DropdownMenuItem(
                                    value: city,
                                    child: Text(city.arabicName),
                                  );
                                }).toList(),
                            onChanged:
                                isSaving
                                    ? null
                                    : (city) {
                                      setState(() => _selectedCity = city);
                                    },
                          ),

                          const SizedBox(height: 16),

                          // Bio Field
                          TextFormField(
                            controller: _bioController,
                            decoration: const InputDecoration(
                              labelText: 'نبذة عنك (اختياري)',
                              hintText: 'أخبر الآخرين عن نفسك...',
                              prefixIcon: Icon(Icons.info_outline),
                              border: OutlineInputBorder(),
                              alignLabelWithHint: true,
                            ),
                            maxLines: 4,
                            maxLength: 500,
                            enabled: !isSaving,
                            textInputAction: TextInputAction.done,
                          ),

                          const SizedBox(height: 24),

                          // Save Button
                          ElevatedButton(
                            onPressed:
                                isSaving
                                    ? null
                                    : () => _saveProfile(innerContext),
                            style: ElevatedButton.styleFrom(
                              minimumSize: const Size(double.infinity, 48),
                            ),
                            child:
                                isSaving
                                    ? const SizedBox(
                                      height: 20,
                                      width: 20,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                      ),
                                    )
                                    : const Text('حفظ التغييرات'),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
      ),
    );
  }

  Widget _buildAvatarSection(bool isSaving) {
    final storage = sl<LocalStorageRepository>();
    final user = storage.getUser();

    return Center(
      child: Stack(
        children: [
          CircleAvatar(
            radius: 60,
            backgroundColor: Colors.grey.shade200,
            backgroundImage:
                user?.avatarUrl != null ? NetworkImage(user!.avatarUrl!) : null,
            child:
                user?.avatarUrl == null
                    ? Icon(Icons.person, size: 60, color: Colors.grey.shade400)
                    : null,
          ),
          Positioned(
            bottom: 0,
            right: 0,
            child: CircleAvatar(
              radius: 20,
              backgroundColor: Theme.of(context).primaryColor,
              child: IconButton(
                icon: const Icon(Icons.camera_alt, size: 20),
                color: Colors.white,
                padding: EdgeInsets.zero,
                onPressed: isSaving ? null : () => _showAvatarOptions(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showAvatarOptions() {
    final storage = sl<LocalStorageRepository>();
    final user = storage.getUser();

    showModalBottomSheet(
      context: context,
      builder:
          (context) => SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: const Icon(Icons.camera_alt),
                  title: const Text('التقاط صورة'),
                  onTap: () {
                    Navigator.pop(context);
                    _pickImageFromCamera();
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.photo_library),
                  title: const Text('اختيار من المعرض'),
                  onTap: () {
                    Navigator.pop(context);
                    _pickImageFromGallery();
                  },
                ),
                if (user?.avatarUrl != null)
                  ListTile(
                    leading: const Icon(Icons.delete, color: Colors.red),
                    title: const Text(
                      'حذف الصورة',
                      style: TextStyle(color: Colors.red),
                    ),
                    onTap: () {
                      Navigator.pop(context);
                      _deleteAvatar();
                    },
                  ),
              ],
            ),
          ),
    );
  }

  Future<void> _pickImageFromCamera() async {
    // TODO: Implement camera picker
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('سيتم تفعيل الكاميرا قريباً')));
  }

  Future<void> _pickImageFromGallery() async {
    // TODO: Implement gallery picker with image_picker
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('سيتم تفعيل المعرض قريباً')));
  }

  void _deleteAvatar() {
    final storage = sl<LocalStorageRepository>();
    final userId = storage.getUserId();

    if (userId != null) {
      context.read<UserBloc>().add(
        DeleteAvatarRequested(userId: userId, context: context),
      );
    }
  }
}
