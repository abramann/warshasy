// ============================================
// lib/features/reviews/domain/entities/review.dart
// ============================================
import 'package:equatable/equatable.dart';

class Review extends Equatable {
  final String id;
  final String professionalId;
  final String clientId;
  final String clientName;
  final String? clientAvatarUrl;
  final int rating;
  final String? comment;
  final DateTime createdAt;

  const Review({
    required this.id,
    required this.professionalId,
    required this.clientId,
    required this.clientName,
    this.clientAvatarUrl,
    required this.rating,
    this.comment,
    required this.createdAt,
  });

  @override
  List<Object?> get props => [
    id,
    professionalId,
    clientId,
    clientName,
    clientAvatarUrl,
    rating,
    comment,
    createdAt,
  ];
}
