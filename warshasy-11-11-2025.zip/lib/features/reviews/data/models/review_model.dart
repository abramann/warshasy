// ============================================
// lib/features/reviews/data/models/review_model.dart
// ============================================
import '../../domain/entities/review.dart';

class ReviewModel extends Review {
  const ReviewModel({
    required super.id,
    required super.professionalId,
    required super.clientId,
    required super.clientName,
    super.clientAvatarUrl,
    required super.rating,
    super.comment,
    required super.createdAt,
  });

  factory ReviewModel.fromJson(Map<String, dynamic> json) {
    return ReviewModel(
      id: json['id'] as String,
      professionalId: json['professional_id'] as String,
      clientId: json['client_id'] as String,
      clientName: json['client_name'] as String? ?? 'Unknown',
      clientAvatarUrl: json['client_avatar_url'] as String?,
      rating: json['rating'] as int,
      comment: json['comment'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'professional_id': professionalId,
      'client_id': clientId,
      'rating': rating,
      'comment': comment,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory ReviewModel.fromEntity(Review entity) {
    return ReviewModel(
      id: entity.id,
      professionalId: entity.professionalId,
      clientId: entity.clientId,
      clientName: entity.clientName,
      clientAvatarUrl: entity.clientAvatarUrl,
      rating: entity.rating,
      comment: entity.comment,
      createdAt: entity.createdAt,
    );
  }
}
