import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as db;
import 'package:warshasy/core/entities/user.dart';
import 'package:warshasy/core/models/user_model.dart';

class ProfilePage extends StatefulWidget {
  final String? userId; // optional: null means current user

  const ProfilePage({Key? key, this.userId}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  User? _user;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final supabase = db.Supabase.instance.client;
    final session = supabase.auth.currentSession;

    // no session? redirect to login
    if (session == null) {
      if (mounted) context.go('/auth');
      return;
    }

    final targetId = widget.userId ?? session.user.id;

    final response =
        await supabase.from('users').select().eq('id', targetId).maybeSingle();

    if (!mounted) return;

    if (response == null) {
      // profile doesn’t exist — only redirect if current user
      if (widget.userId == null) {
        context.go('/profile/profile_setup');
      } else {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('User profile not found')));
        context.pop();
      }
      return;
    }

    setState(() {
      _user = UserModel.fromJson(response);
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (_user == null) {
      return const SizedBox.shrink(); // should never reach here
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.userId == null ? 'My Profile' : _user!.fullName!),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              radius: 40,
              backgroundImage:
                  _user!.avatarUrl != null
                      ? NetworkImage(_user!.avatarUrl!)
                      : null,
              child:
                  _user!.avatarUrl == null
                      ? const Icon(Icons.person, size: 40)
                      : null,
            ),
            const SizedBox(height: 16),
            Text(
              _user!.fullName!,
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 4),
            if (_user!.city != null)
              Text(
                _user!.city!.arabicName,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            const SizedBox(height: 16),
            //if (_user!.bio != null && _user!.bio!.isNotEmpty)
            //  Text(_user!.bio!),
          ],
        ),
      ),
    );
  }
}
