class AuthSession {
  String? phone;
  int? otpCode;

  AuthSession({this.phone, this.otpCode});

  factory AuthSession.fromJson(Map<String, dynamic> json) => AuthSession(
    phone: json['phone'] as String,
    otpCode: json['otp_code'] as int,
  );

  Map<String, dynamic> toJson() {
    return {'phone': phone, 'otp_code': otpCode};
  }
}
