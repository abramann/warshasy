import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:warshasy/core/config/injection_container.dart';
import 'package:warshasy/core/data/repositories/user_repository.dart';
import 'package:warshasy/features/auth/presentation/bloc/auth_bloc.dart';

class AuthGuard {
  final AuthBloc authBloc;

  AuthGuard(this.authBloc);

  Future<String?> handleAuthState(
    BuildContext? context,
    GoRouterState state,
  ) async {
    final authState = authBloc.state;

    if (authState is! AuthSuccess) {
      final user = await sl<UserRepository>().getCurrentUser();
      if (user == null) {
        // User haven't created profile
        return '/profile';
      }
      if (!isSignedUserRoute(state.fullPath!)) return '/home';
    }
    //if (!(authState is AuthSuccess) && !isPublicRoute(state.fullPath!)) {
    //  return '/login';
    //}
    return null;
  }

  bool isSignedUserRoute(String location) {
    return location.startsWith('/home');
  }

  bool isPublicRoute(String location) {
    return location.startsWith('/login');
  }
}
