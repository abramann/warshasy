import 'package:supabase_flutter/supabase_flutter.dart' as db;
import 'package:warshasy/core/models/user_model.dart';
import 'package:warshasy/features/auth/auth.dart';
import 'package:warshasy/core/config/injection_container.dart';
import 'package:warshasy/features/auth/domain/entities/auth_session.dart';

class UserRepository {
  User? _cached;

  Future<User?> getCurrentUser() async {
    if (_cached != null) return _cached;
    final session = sl<AuthSession>();
    _cached = await getUser(session.phone!);
    return _cached;
  }

  Future<User?> getUser(String id) async {
    final response =
        await db.Supabase.instance.client
            .from('users')
            .select()
            .eq('phone', id)
            .single();
    return UserModel.fromJson(response);
  }

  void clearCache() => _cached = null;
}
