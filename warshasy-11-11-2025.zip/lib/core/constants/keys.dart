class AppKeys {
  //static const String apiCallMeBot = 'https://api.example.com';
  //static const String supabaseApiKey = 'your-supabase-api-key';
}
