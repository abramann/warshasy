// This represents what a User IS in your app (business logic)
// Think of it as a blueprint/contract

import 'package:equatable/equatable.dart';
import 'package:warshasy/core/entities/city.dart';

class User extends Equatable {
  final String id;
  final String phone; // Currently phone is primary identifier
  final String? fullName;
  final City? city;
  final String? avatarUrl;
  final DateTime createdAt;

  const User({
    required this.id,
    required this.fullName,
    required this.phone,
    required this.city,
    this.avatarUrl,
    required this.createdAt,
  });

  @override
  List<Object?> get props => [fullName, phone, city, avatarUrl, createdAt];
}
